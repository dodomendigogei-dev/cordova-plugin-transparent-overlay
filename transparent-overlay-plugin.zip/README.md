# Cordova Plugin: Transparent Overlay

Plugin nativo para crear overlay transparente con peluches flotantes sobre cualquier aplicación Android.

## Características

- ✅ Overlay nativo transparente
- ✅ Peluches flotan sobre cualquier app
- ✅ Sin ventanas visibles
- ✅ WebView transparente
- ✅ Comunicación JavaScript-Nativo
- ✅ Foreground service
- ✅ Compatible con VoltBuilder

## Instalación

```bash
cordova plugin add cordova-plugin-transparent-overlay
```

## Uso

```javascript
// Iniciar overlay
cordova.plugins.transparentOverlay.start(
    'overlay-plushies.html',
    function(success) {
        console.log('Overlay iniciado:', success);
    },
    function(error) {
        console.error('Error:', error);
    }
);

// Detener overlay
cordova.plugins.transparentOverlay.stop(
    function(success) {
        console.log('Overlay detenido:', success);
    },
    function(error) {
        console.error('Error:', error);
    }
);

// Verificar estado
cordova.plugins.transparentOverlay.isActive(
    function(active) {
        console.log('Overlay activo:', active === 1);
    }
);
```

## Permisos Requeridos

- `SYSTEM_ALERT_WINDOW` - Para mostrar sobre otras apps
- `FOREGROUND_SERVICE` - Para mantener el overlay activo

## Configuración Android

El plugin agrega automáticamente los permisos necesarios al AndroidManifest.xml.

## Estructura

```
cordova-plugin-transparent-overlay/
├── plugin.xml                    # Configuración del plugin
├── www/
│   └── transparent-overlay.js    # Interfaz JavaScript
└── src/android/
    └── com/dodo/transparentoverlay/
        ├── TransparentOverlay.java     # Plugin principal
        ├── OverlayService.java         # Servicio foreground
        └── OverlayView.java           # Vista transparente
```

## Notas

- Requiere Android 6.0+ (API 23+)
- Necesita permiso "Aparecer encima" activado
- Compatible con VoltBuilder y Cordova CLI
