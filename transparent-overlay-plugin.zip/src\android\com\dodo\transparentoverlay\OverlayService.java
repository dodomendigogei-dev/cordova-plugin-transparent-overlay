package com.dodo.transparentoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.FrameLayout;

public class OverlayService extends Service {
    
    private static OverlayService instance;
    private WindowManager windowManager;
    private View overlayView;
    private WebView webView;
    private static boolean isActive = false;
    private static final String CHANNEL_ID = "overlay_service_channel";
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String htmlUrl = intent.getStringExtra("htmlUrl");
        if (htmlUrl == null) {
            htmlUrl = "file:///android_asset/www/overlay-plushies.html";
        }
        
        if (overlayView == null) {
            createOverlay(htmlUrl);
        }
        
        // Iniciar como foreground service
        startForeground(1, createNotification());
        
        return START_STICKY;
    }
    
    /**
     * Crear el overlay transparente
     */
    private void createOverlay(String htmlUrl) {
        try {
            // Parámetros de la ventana flotante
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? 
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            );
            
            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = 0;
            params.y = 0;
            
            // Crear vista principal transparente
            overlayView = new FrameLayout(this);
            overlayView.setBackgroundColor(0x00000000); // Transparente
            
            // Crear WebView transparente
            webView = createWebView(htmlUrl);
            overlayView.addView(webView);
            
            // Agregar al window manager
            windowManager.addView(overlayView, params);
            isActive = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Crear WebView transparente
     */
    private WebView createWebView(String htmlUrl) {
        WebView webView = new WebView(this);
        
        // Configuración para transparencia
        webView.setBackgroundColor(0x00000000);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        
        // Configuración web
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        
        // Habilitar zoom y scroll
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        
        // WebViewClient para cargar el contenido
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Inyectar JavaScript para comunicación bidireccional
                injectJavaScriptInterface();
            }
        });
        
        // Cargar el HTML
        webView.loadUrl(htmlUrl);
        
        return webView;
    }
    
    /**
     * Inyectar interfaz JavaScript para comunicación
     */
    private void injectJavaScriptInterface() {
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void postMessage(String message) {
                // Recibir mensajes del JavaScript
                handleJSMessage(message);
            }
            
            @android.webkit.JavascriptInterface
            public void closeOverlay() {
                stopSelf();
            }
        }, "AndroidOverlay");
    }
    
    /**
     * Manejar mensajes desde JavaScript
     */
    private void handleJSMessage(String message) {
        // Procesar mensajes desde el overlay
        if ("close".equals(message)) {
            stopSelf();
        }
    }
    
    /**
     * Actualizar contenido del WebView
     */
    public static void updateContent(String htmlContent) {
        if (instance != null && instance.webView != null) {
            instance.webView.post(() -> {
                instance.webView.loadDataWithBaseURL(
                    "file:///android_asset/www/",
                    htmlContent,
                    "text/html",
                    "UTF-8",
                    null
                );
            });
        }
    }
    
    /**
     * Actualizar configuración de peluches
     */
    public static void updatePlushies(String plushieConfig) {
        if (instance != null && instance.webView != null) {
            instance.webView.post(() -> {
                String js = "updatePlushiesConfig(" + plushieConfig + ");";
                instance.webView.evaluateJavascript(js, null);
            });
        }
    }
    
    /**
     * Verificar si está activo
     */
    public static boolean isActive() {
        return isActive;
    }
    
    /**
     * Crear notificación para foreground service
     */
    private android.app.Notification createNotification() {
        try {
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
            PendingIntent pendingIntent = null;
            if (launchIntent != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    pendingIntent = PendingIntent.getActivity(this, 0, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                } else {
                    pendingIntent = PendingIntent.getActivity(this, 0, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                }
            }

            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (nm != null) {
                    NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "Overlay Service",
                        NotificationManager.IMPORTANCE_LOW
                    );
                    channel.setDescription("Transparent overlay for plushies");
                    nm.createNotificationChannel(channel);
                }

                Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Plushies")
                    .setContentText("Running")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setOngoing(true);

                if (pendingIntent != null) builder.setContentIntent(pendingIntent);

                return builder.build();
            } else {
                Notification.Builder builder = new Notification.Builder(this)
                    .setContentTitle("Plushies")
                    .setContentText("Running")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setOngoing(true);

                if (pendingIntent != null) builder.setContentIntent(pendingIntent);

                return builder.build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        
        if (overlayView != null && windowManager != null) {
            windowManager.removeView(overlayView);
            overlayView = null;
        }
        
        isActive = false;
        instance = null;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
