package com.dodo.transparentoverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

public class OverlayView extends View {
    
    private Paint paint;
    private boolean isInitialized = false;
    
    public OverlayView(Context context) {
        super(context);
        init();
    }
    
    public OverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    
    public OverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }
    
    private void init() {
        if (!isInitialized) {
            paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(0x00000000); // Transparente
            isInitialized = true;
        }
    }
    
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Canvas transparente - no dibuja nada
        canvas.drawColor(0x00000000);
    }
    
    /**
     * Actualizar la vista del overlay
     */
    public void updateOverlay() {
        invalidate();
    }
}
