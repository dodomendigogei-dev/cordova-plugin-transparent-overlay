package com.dodo.transparentoverlay;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import android.content.Intent;

public class TransparentOverlay extends CordovaPlugin {
    
    private static final String ACTION_START = "start";
    private static final String ACTION_STOP = "stop";
    private static final String ACTION_IS_ACTIVE = "isActive";
    private static final String ACTION_UPDATE_CONTENT = "updateContent";
    private static final String ACTION_UPDATE_PLUSHIES = "updatePlushies";
    
    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        
        if (ACTION_START.equals(action)) {
            String htmlUrl = args.optString(0, "overlay-plushies.html");
            this.startOverlay(htmlUrl, callbackContext);
            return true;
            
        } else if (ACTION_STOP.equals(action)) {
            this.stopOverlay(callbackContext);
            return true;
            
        } else if (ACTION_IS_ACTIVE.equals(action)) {
            this.checkActive(callbackContext);
            return true;
            
        } else if (ACTION_UPDATE_CONTENT.equals(action)) {
            String htmlContent = args.getString(0);
            this.updateContent(htmlContent, callbackContext);
            return true;
            
        } else if (ACTION_UPDATE_PLUSHIES.equals(action)) {
            String plushieConfig = args.getString(0);
            this.updatePlushies(plushieConfig, callbackContext);
            return true;
        }
        
        return false;
    }
    
    /**
     * Iniciar el overlay transparente
     */
    private void startOverlay(String htmlUrl, CallbackContext callbackContext) {
        try {
            Intent intent = new Intent(cordova.getActivity(), OverlayService.class);
            intent.putExtra("htmlUrl", htmlUrl);
            cordova.getActivity().startService(intent);
            callbackContext.success("Overlay iniciado");
        } catch (Exception e) {
            callbackContext.error("Error iniciando overlay: " + e.getMessage());
        }
    }
    
    /**
     * Detener el overlay
     */
    private void stopOverlay(CallbackContext callbackContext) {
        try {
            Intent intent = new Intent(cordova.getActivity(), OverlayService.class);
            cordova.getActivity().stopService(intent);
            callbackContext.success("Overlay detenido");
        } catch (Exception e) {
            callbackContext.error("Error deteniendo overlay: " + e.getMessage());
        }
    }
    
    /**
     * Verificar si está activo
     */
    private void checkActive(CallbackContext callbackContext) {
        try {
            boolean isActive = OverlayService.isActive();
            callbackContext.success(isActive ? 1 : 0);
        } catch (Exception e) {
            callbackContext.error("Error verificando overlay: " + e.getMessage());
        }
    }
    
    /**
     * Actualizar contenido del overlay
     */
    private void updateContent(String htmlContent, CallbackContext callbackContext) {
        try {
            OverlayService.updateContent(htmlContent);
            callbackContext.success("Contenido actualizado");
        } catch (Exception e) {
            callbackContext.error("Error actualizando contenido: " + e.getMessage());
        }
    }
    
    /**
     * Actualizar configuración de peluches
     */
    private void updatePlushies(String plushieConfig, CallbackContext callbackContext) {
        try {
            OverlayService.updatePlushies(plushieConfig);
            callbackContext.success("Peluches actualizados");
        } catch (Exception e) {
            callbackContext.error("Error actualizando peluches: " + e.getMessage());
        }
    }
}
